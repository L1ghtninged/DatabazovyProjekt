﻿namespace DatabazovyProjekt
{
    public class AdminEntry
    {
        public int Id { get; set; }
        public string Jmeno { get; set; } = "";
        public string Prijmeni { get; set; } = "";
        public string Email { get; set; } = "";

    }
}
